const username=document.getElementById("username");
const saveScoreBtn=document.getElementById("saveScoreButton");
const mostRecentScore=localStorage.getItem("mostRecentScore");
const finalScore=document.getElementById("finalScore")
finalScore.innerText=`Total Score ${mostRecentScore}`;

//-------high scoes of latest 5 students
//const highScore=[]
const highScore=JSON.parse(localStorage.getItem("highScores",JSON.stringify([]))) || [];
console.log(highScore);

saveScoreBtn.disabled = !username.value.trim();

username.addEventListener("input", () => {
  //console.log('Input event triggered',username.value);
  if(username.value.trim()==''){
    saveScoreBtn.disabled=true;
  }else{
    saveScoreBtn.disabled=false;
      // console.log('falsiii');
  }
  //saveScoreBtn.disabled = !username.value.trim();
});

saveHighScore=e=>{
  console.log('save hight score button',e);
  e.preventDefault()
  
  //------------
  const score={
    score:Math.floor(Math.random()*100),
   // score:mostRecentScore,
    name:username.value
  }
  console.log('random score',score.score,"name",score.name);
  highScore.push(score);
  console.log('high score',highScore);
  highScore.sort((a,b)=> b.score-a.score)
  highScore.splice(4)
localStorage.setItem("highScore",JSON.stringify(highScore))
window.location.assign('/')
}

