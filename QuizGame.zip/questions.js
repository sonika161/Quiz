  URL="https://opentdb.com/api.php?amount=10&category=18&difficulty=easy&type=multiple";
  export default URL;
// [
//   {
//   "questions":"inside which you select?1",
//   "choice1":"jave",
//   "choice2":"java2",
//   "choice3":"java3",
//   "choice4":"java4",
//   "Answer":1
// },
// {
//   "questions":"inside which you select?2",
//   "choice1":"jave",
//   "choice2":"java2",
//   "choice3":"java3",
//   "choice4":"java4",
//   "Answer":1
// },
// {
//   "questions":"inside which you select?3",
//   "choice1":"jave",
//   "choice2":"java2",
//   "choice3":"java3",
//   "choice4":"java4",
//   "Answer":1
// },
// {
//   "questions":"inside which you select?4",
//   "choice1":"jave",
//   "choice2":"java2",
//   "choice3":"java3",
//   "choice4":"java4",
//   "Answer":1
// }
// ]