//import URL from "./questions.js";
URL="https://opentdb.com/api.php?amount=10&category=18&difficulty=easy&type=multiple";
const questions=document.getElementById("questions");
//const choice=Array(document.getElementsByClassName("choice-text"));
const choice = document.getElementsByClassName("choice-text"); 
const progressText=document.getElementById('progressText');
const scoreText=document.getElementById('score');
const loader=document.getElementById("loader");
const game=document.getElementById("game");
const elementsByClass=document.getElementsByClassName('progress-Bar-full')
const progressBar = elementsByClass[0];
//console.log('choic',choice);
let currentQuestion={}
let acceptAns=false;
let availableQuestion=[];
let score=0;
let counter=0;
let static_questions=[]
//constants
const CORRECT_BONUS=10;


let startGame=()=>{
  counter=0;
  availableQuestion=[...static_questions];
  score=0;
  console.log(availableQuestion,'av question');
  getNewQuestion();
  game.classList.remove("hidden");
  loader.classList.add("hidden");
}
getNewQuestion=()=>{
  if(availableQuestion.length===0||counter>=MAX_QUES){
    //go to end page
    return window.location.assign("/end.html")
   
  }
counter++;
//progressText.innerHTML=`${counter}/${availableQuestion.length}`;
progressText.innerHTML=`Question ${counter}/${MAX_QUES}`;
//---------progress bar

const questionIndex=Math.floor(Math.random()* availableQuestion.length);
currentQuestion=availableQuestion[questionIndex]
//console.log('cuurent',currentQuestion);
questions.innerText =  currentQuestion.question
//console.log('ques inner',currentQuestion.questions);
Array.from(choice).forEach((choiceElement, index) => {
  const number=choiceElement.dataset.number;
  //console.log('looopp',index, choiceElement.dataset.number); // Log the index and the choice element
  choiceElement.innerText = currentQuestion["choice"+ number]
  //console.log('choicesss',choice.innerText);
});

//-------------------------------splice used ques
availableQuestion.splice(currentQuestion,1);
//console.log('ques removed',questionIndex,availableQuestion.splice(currentQuestion,1));
acceptAns=true
}

//----------------API-----------------------------

fetch(URL).then(res=>{
  return res.json();
}).then(loadQuestions=>{
   MAX_QUES=loadQuestions.results.length; //global variable
  //console.log('load ques',loadQuestions.results.length);
  //------ques
  static_questions=loadQuestions.results.map(loadQuestions=>{
    const formattedQuestion={
      question:loadQuestions.question
    };
    //console.log('formattedQuestion',formattedQuestion);
    //-----correct ans
     const ansChoice=[...loadQuestions.incorrect_answers];
    formattedQuestion.answer=Math.floor(Math.random()*3)+1;
     console.log('ansChoice',loadQuestions.correct_answer);
     ansChoice.splice(formattedQuestion.answer-1,0,loadQuestions.correct_answer);
     console.log('ans choice',ansChoice);
    
     ansChoice.forEach((choice,index)=>{
      formattedQuestion["choice"+(index+1)]=choice;
    });
    
    return formattedQuestion;
    
  });
  
  startGame()
}).catch(error=>{
  console.error (error);
});

//-------------------------------------------------------------


  





Array.from(choice).forEach((item, index) => {
  item.addEventListener("click",event=>{
    //console.log('event',event.target);
    if(!availableQuestion)return;
    acceptAns=false;
    const selectedChoice=event.target;
    const selectedAns=selectedChoice.dataset.number;
    
    // const classToApply='incorrect';
    // if(selectedAns==currentQuestion.Answer){
    //   classToCorrect='correct'
    // }else{

    //} 
    const classToApply= selectedAns==currentQuestion.answer?
      'correct' :'incorrect';
      
    if(classToApply=="correct"){
      incrementScore(CORRECT_BONUS);
      progressBar.style.width=`${(counter/MAX_QUES)*100}%`;
      console.log('@@@@',progressBar,'progress bar');
    }

      selectedChoice.parentElement.classList.add(classToApply)
    
    setTimeout(()=>{
      selectedChoice.parentElement.classList.remove(classToApply)
    },1000);
    


    //console.log('selectedAns',selectedAns);
    getNewQuestion()
  })

  incrementScore=num=>{
    score+=num;
    scoreText.innerHTML=score ? score : 0;
    console.log(score,'score');
    localStorage.setItem("mostRecentScore",score)
  } 
  
}) 
 
