//const highScore=JSON.parse(localStorage.getItem("highScore"));
const highScoresList=document.getElementById("highScoresList")


// Retrieve high scores from localStorage
const storedHighScores = localStorage.getItem("highScore");

// Check if storedHighScores is not null before parsing
const highScore = storedHighScores ? JSON.parse(storedHighScores) : [];

//const highScore=JSON.parse(localStorage.getItem("highScores",JSON.stringify([]))) || [];
highScoresList.innerHTML=highScore.map(score=>{
   return `<li class="high-score">${score.score}-${score.name}</li>`;
  //console.log(`<li class="high-score">${score.score}-${score.name}</li>`);
}).join(" ")
